import React from "react";
import "./Main.css"

const Main = () =>{
    return(
        <div className="mainKonten">
            <h1>Main</h1>
            <img src="myapp/src/components/padang.png" alt="" />            
        </div>
    )
}

export default Main;