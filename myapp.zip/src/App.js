import  React from "react"
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom"
import Navbar from "./components/Navbar.js"
import Main from "./components/Main.jsx";
import Footer from "./components/Footer";
import About from "./components/About";
import Contact from "./components/Contact";



function App() {
    return (
        <Router>       
            <Navbar/>
            <Routes>
                <Route index element ={<Main/>}/>
                <Route path="about" element ={<About/>}/>
                <Route path="contact" element ={<Contact/>}/>
            </Routes>
        </Router>
    )
}


export default App;